package com.example.u_ifood_

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
