import 'package:flutter/material.dart';

class Perfil extends StatelessWidget {
  const Perfil({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        actions: const [
          Padding(
            padding: EdgeInsets.all(8.0),
            child: Icon(Icons.qr_code),
          ),
        ],
      ),
      body: ListView(
        children: [
          Row(
            children: [
              Container(
                margin: const EdgeInsets.all(16),
                width: 56,
                height: 56,
                child: const CircleAvatar(
                  radius: 50,
                  backgroundImage: NetworkImage('assets/icone-ifood.png'),
                ),
              ),
              const Text('GGG')
            ],
          ),
          Wrap(
            children: [
              _Part(
                cor: Color.fromARGB(255, 161, 151, 151),
                texto: 'Conversa',
                img: 'assets/icone-ifood.png',
              ),
              _Part(
                cor: Color.fromARGB(255, 161, 151, 151),
                texto: 'Notificações',
                img: 'assets/icone-ifood.png',
              ),
              _Part(
                cor: Color.fromARGB(255, 161, 151, 151),
                texto: 'Pagamentos',
                img: 'assets/icone-ifood.png',
              ),
              _Part(
                cor: Color.fromARGB(255, 161, 151, 151),
                texto: 'Assinaturas',
                img: 'assets/icone-ifood.png',
              ),
              _Part(
                cor: Color.fromARGB(255, 161, 151, 151),
                texto: 'Clube iFood',
                img: 'assets/icone-ifood.png',
              ),
              _Part(
                cor: Color.fromARGB(255, 161, 151, 151),
                texto: 'Cupons',
                img: 'assets/icone-ifood.png',
              ),
            ],
          ),
        ],
      ),
    );
  }
}

class _Part extends StatelessWidget {
  final Color cor;
  final String img;
  final String texto;

  _Part({
    required this.cor,
    required this.img,
    required this.texto,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      width: 250,
      margin: const EdgeInsets.all(8),
      height: 50,
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(8),
        color: cor,
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceAround,
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          Text(texto),
          Image.asset(
            img,
            width: 32,
            height: 32,
          ),
        ],
      ),
    );
  }
}
