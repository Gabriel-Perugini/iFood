import 'package:flutter/material.dart';

class Carrinho extends StatelessWidget {
  const Carrinho ({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: ListView(
        children: [
          Wrap(
            children: [
              _container(Color.fromARGB(255, 255, 0, 0), 'X-Egg', 'assets/XOvo.jpg'),
              _container(Color.fromARGB(255, 255, 230, 0), 'Coca Zero', 'assets/CocaZero.jpg'),
              _container(Color.fromARGB(255, 0, 255, 234), 'Batata', 'assets/Batata.jpg'),
              _container(Color.fromARGB(255, 98, 0, 255), 'Açai', 'assets/acai.jpg'),
              _container(Color.fromARGB(255, 255, 0, 140), 'blank', 'assets/icone-ifood.png'),
              _container(Color.fromARGB(255, 0, 255, 136), 'blank', 'assets/icone-ifood.png'),
              _container(Color.fromARGB(255, 246, 147, 0), 'blank', 'assets/icone-ifood.png')
            ],
          )
        ],
      ),
    );
  }
}

_container(Color cor, texto, img){
  return Container(
    width: 150,
    margin: const EdgeInsets.all(8),
    height: 100,
    decoration: 
        BoxDecoration(borderRadius: BorderRadius.circular(8), color: cor),
    child: Row(
      mainAxisAlignment: MainAxisAlignment.spaceAround,
      crossAxisAlignment: CrossAxisAlignment.center,
      children: [
        Text(texto),
        Image.asset(img, width: 64, height: 64,)
      ],
    ),
  );
}