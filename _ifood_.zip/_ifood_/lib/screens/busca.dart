import 'package:flutter/material.dart';

class Busca extends StatelessWidget {
  const Busca ({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: ListView(
        children: [
          Wrap(
            children: [
              _container(Colors.orange, 'Lanches', 'assets/ifood.jpg'),
              _container(Colors.orange, 'Bebidas', 'assets/CocaZero.jpg'),
              _container(Colors.orange, 'Açai', 'assets/acai.jpg'),
              _container(Colors.orange, 'Sides', 'assets/Batata.jpg')
            ],
          )
        ],
      ),
    );
  }
}

_container(Color cor, texto, img){
  return Container(
    width: 150,
    margin: const EdgeInsets.all(8),
    height: 100,
    decoration: 
        BoxDecoration(borderRadius: BorderRadius.circular(8), color: cor),
    child: Row(
      mainAxisAlignment: MainAxisAlignment.spaceAround,
      crossAxisAlignment: CrossAxisAlignment.center,
      children: [
        Text(texto),
        Image.asset(img, width: 64, height: 64,)
      ],
    ),
  );
}