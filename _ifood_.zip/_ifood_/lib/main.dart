import 'package:_ifood_/myapp.dart';
import 'package:flutter/material.dart';
import 'package:_ifood_/screens/homepage.dart';
import 'package:_ifood_/screens/carrinho.dart';

void main(){
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return const MaterialApp(
      debugShowCheckedModeBanner: false,
      home: HomePage(),
    );
  }
}